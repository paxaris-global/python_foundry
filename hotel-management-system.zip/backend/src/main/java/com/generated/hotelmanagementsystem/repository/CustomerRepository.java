package com.generated.hotelmanagementsystem.repository;

import com.generated.hotelmanagementsystem.entity.Customer;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CustomerRepository extends JpaRepository<Customer, UUID> {
}
