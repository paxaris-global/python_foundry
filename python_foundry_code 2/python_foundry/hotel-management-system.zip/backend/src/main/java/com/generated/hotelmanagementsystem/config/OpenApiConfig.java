package com.generated.hotelmanagementsystem.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.License;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {
    
    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI()
            .info(new Info()
                .title("hotel-management-system API")
                .version("1.0.0")
                .description("Generate a production-ready hotel management system with Spring Boot backend and Angular frontend, including authentication, role-based access, dashboard, CRUD modules for rooms, bookings, guests, and staff management, Docker support, tests, and README.")
                .contact(new Contact()
                    .name("API Support")
                    .url("https://example.com"))
                .license(new License()
                    .name("Apache 2.0")
                    .url("https://www.apache.org/licenses/LICENSE-2.0.html")));
    }
}
