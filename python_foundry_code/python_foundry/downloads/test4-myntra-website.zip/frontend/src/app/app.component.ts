import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  readonly title = 'Test4 Myntra Website';
  readonly promo = 'Flat 25% OFF | Free shipping over $49';
  readonly topCategories = ['MEN', 'WOMEN', 'KIDS', 'BEAUTY', 'HOME', 'ACCESSORIES'];
  readonly megaMenu: Record<string, string[]> = {
    MEN: ['T-Shirts', 'Shirts', 'Jeans', 'Footwear', 'Watches', 'Sportswear'],
    WOMEN: ['Dresses', 'Tops', 'Kurtas', 'Heels', 'Handbags', 'Jewellery'],
    KIDS: ['Boys Clothing', 'Girls Clothing', 'Infantwear', 'Toys', 'School'],
    BEAUTY: ['Makeup', 'Skincare', 'Haircare', 'Fragrances', 'Grooming'],
    HOME: ['Bedsheets', 'Decor', 'Kitchen', 'Bath', 'Storage'],
    ACCESSORIES: ['Watches', 'Belts', 'Wallets', 'Sunglasses', 'Bags'],
  };
  activeMegaMenu: string | null = null;

  openMegaMenu(category: string): void {
    this.activeMegaMenu = category;
  }

  closeMegaMenu(): void {
    this.activeMegaMenu = null;
  }
}
