package com.generated.test4myntrawebsite.repository;

import com.generated.test4myntrawebsite.entity.Customer;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CustomerRepository extends JpaRepository<Customer, UUID> {
}
