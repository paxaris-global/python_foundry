package com.generated.test4myntrawebsite;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Test4MyntraWebsiteApplication {
    public static void main(String[] args) {
        SpringApplication.run(Test4MyntraWebsiteApplication.class, args);
    }
}
