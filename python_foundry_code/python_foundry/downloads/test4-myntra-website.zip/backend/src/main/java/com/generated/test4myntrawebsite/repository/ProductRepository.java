package com.generated.test4myntrawebsite.repository;

import com.generated.test4myntrawebsite.entity.Product;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductRepository extends JpaRepository<Product, UUID> {
}
