package com.generated.test4myntrawebsite;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Test4MyntraWebsiteApplicationTests {
    @Test
    void contextLoads() {
    }
}
