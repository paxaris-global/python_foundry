package com.generated.testceleryfix;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestCeleryFixApplicationTests {
    @Test
    void contextLoads() {
    }
}
