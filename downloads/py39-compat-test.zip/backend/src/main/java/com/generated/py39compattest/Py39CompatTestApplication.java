package com.generated.py39compattest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Py39CompatTestApplication {
    public static void main(String[] args) {
        SpringApplication.run(Py39CompatTestApplication.class, args);
    }
}
