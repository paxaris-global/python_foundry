package com.generated.py39compattest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Py39CompatTestApplicationTests {
    @Test
    void contextLoads() {
    }
}
