import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  private apiUrl = environment.apiBaseUrl;

  constructor(private http: HttpClient) {}

  private getHeaders(): HttpHeaders {
    return new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${localStorage.getItem('token')}`
    });
  }

  getProducts(): Observable<any> {
    return this.http.get(`${this.apiUrl}/products`, { headers: this.getHeaders() });
  }

  getProductById(productId: string): Observable<any> {
    return this.http.get(`${this.apiUrl}/products/${productId}`, { headers: this.getHeaders() });
  }

  addToCart(productId: string, quantity: number): Observable<any> {
    return this.http.post(`${this.apiUrl}/cart`, { productId, quantity }, { headers: this.getHeaders() });
  }

  getCart(): Observable<any> {
    return this.http.get(`${this.apiUrl}/cart`, { headers: this.getHeaders() });
  }

  checkout(cartId: string, paymentDetails: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/checkout`, { cartId, paymentDetails }, { headers: this.getHeaders() });
  }

  login(credentials: { email: string, password: string }): Observable<any> {
    return this.http.post(`${this.apiUrl}/auth/login`, credentials, { headers: this.getHeaders() });
  }

  register(userDetails: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/auth/register`, userDetails, { headers: this.getHeaders() });
  }

  getUserProfile(): Observable<any> {
    return this.http.get(`${this.apiUrl}/user/profile`, { headers: this.getHeaders() });
  }

  updateUserProfile(profileData: any): Observable<any> {
    return this.http.put(`${this.apiUrl}/user/profile`, profileData, { headers: this.getHeaders() });
  }

  getAdminDashboardData(): Observable<any> {
    return this.http.get(`${this.apiUrl}/admin/dashboard`, { headers: this.getHeaders() });
  }

  manageProduct(productData: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/admin/products`, productData, { headers: this.getHeaders() });
  }

  manageOrder(orderId: string, status: string): Observable<any> {
    return this.http.put(`${this.apiUrl}/admin/orders/${orderId}`, { status }, { headers: this.getHeaders() });
  }
}