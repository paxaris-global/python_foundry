import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'E-Commerce Platform';

  // Sample data for demonstration
  featuredProducts = [
    { id: 1, name: 'Product 1', price: 29.99, imageUrl: 'assets/images/product1.jpg' },
    { id: 2, name: 'Product 2', price: 49.99, imageUrl: 'assets/images/product2.jpg' },
    { id: 3, name: 'Product 3', price: 19.99, imageUrl: 'assets/images/product3.jpg' }
  ];

  categories = [
    { id: 1, name: 'Electronics' },
    { id: 2, name: 'Fashion' },
    { id: 3, name: 'Home & Garden' }
  ];

  constructor() {}

  // Method to handle adding a product to the cart
  addToCart(productId: number) {
    console.log(`Product ${productId} added to cart`);
    // Logic to add product to cart
  }

  // Method to handle user authentication
  authenticateUser() {
    console.log('User authentication process');
    // Logic for user authentication
  }

  // Method to navigate to product details
  viewProductDetails(productId: number) {
    console.log(`Navigating to details of product ${productId}`);
    // Logic to navigate to product details page
  }
}