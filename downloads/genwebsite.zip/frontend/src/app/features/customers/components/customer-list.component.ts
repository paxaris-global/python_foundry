import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../../services/customer.service';
import { Customer } from '../../models/customer.model';

@Component({
  selector: 'app-customer-list',
  templateUrl: './customer-list.component.html',
  styleUrls: ['./customer-list.component.scss']
})
export class CustomerListComponent implements OnInit {
  customers: Customer[] = [];
  isLoading: boolean = true;
  errorMessage: string = '';

  constructor(private customerService: CustomerService) {}

  ngOnInit(): void {
    this.fetchCustomers();
  }

  fetchCustomers(): void {
    this.customerService.getCustomers().subscribe(
      (data: Customer[]) => {
        this.customers = data;
        this.isLoading = false;
      },
      (error) => {
        this.errorMessage = 'Failed to load customers. Please try again later.';
        this.isLoading = false;
      }
    );
  }

  trackByCustomerId(index: number, customer: Customer): number {
    return customer.id;
  }
}

<!-- customer-list.component.html -->
<div class="customer-list-container">
  <div *ngIf="isLoading" class="loading-spinner">
    <mat-spinner></mat-spinner>
  </div>
  <div *ngIf="errorMessage" class="error-message">
    {{ errorMessage }}
  </div>
  <div *ngIf="!isLoading && !errorMessage">
    <mat-card *ngFor="let customer of customers; trackBy: trackByCustomerId" class="customer-card">
      <mat-card-header>
        <mat-card-title>{{ customer.name }}</mat-card-title>
        <mat-card-subtitle>{{ customer.email }}</mat-card-subtitle>
      </mat-card-header>
      <mat-card-content>
        <p>Joined: {{ customer.joinDate | date }}</p>
        <p>Orders: {{ customer.orderCount }}</p>
      </mat-card-content>
      <mat-card-actions>
        <button mat-button color="primary">View Details</button>
        <button mat-button color="warn">Delete</button>
      </mat-card-actions>
    </mat-card>
  </div>
</div>

<!-- customer-list.component.scss -->
.customer-list-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 20px;
}

.loading-spinner {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
}

.error-message {
  color: red;
  font-size: 1.2em;
  margin-top: 20px;
}

.customer-card {
  width: 100%;
  max-width: 600px;
  margin-bottom: 20px;
}

mat-card-header {
  background-color: #f5f5f5;
}

mat-card-title {
  font-weight: bold;
}

mat-card-actions {
  display: flex;
  justify-content: flex-end;
}