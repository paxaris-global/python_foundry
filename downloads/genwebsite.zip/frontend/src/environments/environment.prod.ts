export const environment = {
  production: true,
  apiUrl: 'https://api.yourdomain.com',
  firebaseConfig: {
    apiKey: 'YOUR_FIREBASE_API_KEY',
    authDomain: 'yourdomain.firebaseapp.com',
    projectId: 'yourdomain',
    storageBucket: 'yourdomain.appspot.com',
    messagingSenderId: 'YOUR_MESSAGING_SENDER_ID',
    appId: 'YOUR_APP_ID',
    measurementId: 'YOUR_MEASUREMENT_ID'
  },
  features: {
    enableProductSearch: true,
    enableUserReviews: true,
    enableWishlist: true,
    enableOrderTracking: true
  },
  uiSettings: {
    theme: 'light', // Options: 'light', 'dark'
    primaryColor: '#1976d2',
    secondaryColor: '#424242',
    accentColor: '#82b1ff',
    navbar: {
      logo: '/assets/logo.png',
      links: [
        { name: 'Home', route: '/' },
        { name: 'Shop', route: '/shop' },
        { name: 'Categories', route: '/categories' },
        { name: 'Contact', route: '/contact' }
      ]
    },
    footer: {
      columns: [
        {
          title: 'Company',
          links: [
            { name: 'About Us', route: '/about' },
            { name: 'Careers', route: '/careers' },
            { name: 'Blog', route: '/blog' }
          ]
        },
        {
          title: 'Support',
          links: [
            { name: 'Help Center', route: '/help' },
            { name: 'Returns', route: '/returns' },
            { name: 'Contact Us', route: '/contact' }
          ]
        }
      ],
      socialLinks: [
        { platform: 'Facebook', url: 'https://facebook.com/yourpage' },
        { platform: 'Twitter', url: 'https://twitter.com/yourpage' },
        { platform: 'Instagram', url: 'https://instagram.com/yourpage' }
      ]
    }
  }
};