export const environment = {
  production: false,
  apiBaseUrl: 'http://localhost:8080/api',
  firebaseConfig: {
    apiKey: 'YOUR_FIREBASE_API_KEY',
    authDomain: 'your-app.firebaseapp.com',
    projectId: 'your-app-id',
    storageBucket: 'your-app.appspot.com',
    messagingSenderId: 'YOUR_MESSAGING_SENDER_ID',
    appId: 'YOUR_APP_ID',
    measurementId: 'YOUR_MEASUREMENT_ID'
  },
  featureFlags: {
    enableNewUI: true,
    enableProductRecommendations: true,
    enableDiscounts: true
  },
  uiSettings: {
    theme: 'light', // Options: 'light', 'dark'
    primaryColor: '#1976d2',
    secondaryColor: '#424242',
    accentColor: '#ff4081',
    navbar: {
      position: 'fixed', // Options: 'fixed', 'static'
      showSearch: true,
      showCartIcon: true,
      showUserMenu: true
    },
    homepage: {
      showHeroSection: true,
      showFeaturedProducts: true,
      showCategories: true,
      heroSection: {
        backgroundImage: 'assets/images/hero-bg.jpg',
        title: 'Welcome to Our Store',
        subtitle: 'Discover amazing products at unbeatable prices',
        ctaButton: {
          text: 'Shop Now',
          link: '/products'
        }
      }
    },
    footer: {
      showNewsletterSignup: true,
      showSocialMediaLinks: true,
      showContactInfo: true
    }
  }
};