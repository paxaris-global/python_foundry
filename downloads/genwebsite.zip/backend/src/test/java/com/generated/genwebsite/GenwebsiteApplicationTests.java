package com.generated.genwebsite;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GenwebsiteApplicationTests {
    @Test
    void contextLoads() {
    }
}
