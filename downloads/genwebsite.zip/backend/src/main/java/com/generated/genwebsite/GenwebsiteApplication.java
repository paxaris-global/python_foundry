package com.generated.genwebsite;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GenwebsiteApplication {
    public static void main(String[] args) {
        SpringApplication.run(GenwebsiteApplication.class, args);
    }
}
