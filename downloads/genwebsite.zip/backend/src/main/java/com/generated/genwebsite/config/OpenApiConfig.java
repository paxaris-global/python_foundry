package com.generated.genwebsite.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.License;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {
    
    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI()
            .info(new Info()
                .title("genwebsite API")
                .version("1.0.0")
                .description("Build a modern, responsive, and production-ready e-commerce website with a clean and attractive UI. Use Angular for the frontend and Spring Boot for the backend. The application should allow users to browse products, view product details, add items to cart, and perform checkout operations. Include user authentication and an admin panel for managing products and orders. Design a visually appealing homepage with a professional navbar, hero section, featured products, categories, and footer. Ensure smooth API integration, scalable architecture, and a fully runnable project with proper structure.")
                .contact(new Contact()
                    .name("API Support")
                    .url("https://example.com"))
                .license(new License()
                    .name("Apache 2.0")
                    .url("https://www.apache.org/licenses/LICENSE-2.0.html")));
    }
}
