# genwebsite

Build a modern, responsive, and production-ready e-commerce website with a clean and attractive UI. Use Angular for the frontend and Spring Boot for the backend. The application should allow users to browse products, view product details, add items to cart, and perform checkout operations. Include user authentication and an admin panel for managing products and orders. Design a visually appealing homepage with a professional navbar, hero section, featured products, categories, and footer. Ensure smooth API integration, scalable architecture, and a fully runnable project with proper structure.

## Stack
- Backend: springboot
- Frontend: angular

## Features
- addeditdelete products
- admin dashboard
- api integration
- auth
- catalog
- category filtering
- checkout flow
- jwt authentication
- order management
- orders
- payments
- product details page
- product listing
- responsive design
- search functionality
- shopping cart
- user authentication

## Project Structure
- backend/: Spring Boot API
- frontend/: Angular SPA
- docker-compose.yml: Local deployment with PostgreSQL
- api-contract.json: Generated API description
- manifest.json: Build manifest

## Run Locally
1. Copy .env.example to .env if needed
2. Build and run:
   docker compose up --build
3. Backend: http://localhost:8080
4. Frontend: http://localhost:4200

## Local Database Options
- By default, the generated backend runs with PostgreSQL in Docker (profile: `postgres`).
- To run with an in-memory H2 database for local development, set:
  - `SPRING_PROFILES_ACTIVE=local`
  - In `backend/src/main/resources/application.yml`, the `local` profile uses H2.
- For production use with SQL DB, set:
  - `SPRING_PROFILES_ACTIVE=postgres`
  - Ensure PostgreSQL running and correct credentials in `application.yml`.

## Notes
- The backend includes layered architecture with DTO, entity, repository, service, controller, and global exception handling.
- The frontend includes routing, feature components, and API integration service.
